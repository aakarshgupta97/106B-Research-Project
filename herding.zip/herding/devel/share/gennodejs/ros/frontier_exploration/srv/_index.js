
"use strict";

let GetNextFrontier = require('./GetNextFrontier.js')
let UpdateBoundaryPolygon = require('./UpdateBoundaryPolygon.js')

module.exports = {
  GetNextFrontier: GetNextFrontier,
  UpdateBoundaryPolygon: UpdateBoundaryPolygon,
};
