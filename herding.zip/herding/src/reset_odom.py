import rospy

from std_msgs.msg import Empty
from time import time

bots = ['/pink', '/green', '/black', '/blue']
#bots = ['/green']

# set up node
rospy.init_node('reset_odom')

for bot in bots:
	raw_input('Reset ' + bot + "?")
	# set up the odometry reset publisher
	reset_odom = rospy.Publisher(bot + '/mobile_base/commands/reset_odometry', Empty, queue_size=10)
	
	# reset odometry (these messages take a few iterations to get through)
	timer = time()
	while time() - timer < 1.0:
	    reset_odom.publish(Empty())
