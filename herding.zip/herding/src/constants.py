turtlebot_colors = ['blue', 'black', 'green', 'yellow', 'pink']
