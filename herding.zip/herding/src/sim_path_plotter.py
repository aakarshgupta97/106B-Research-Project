#!/usr/bin/env python
import rospy
from rospy import client
from geometry_msgs.msg import Point
import matplotlib
import numpy as np
import matplotlib.pyplot as plt

class SimPathPlotter:
    def __init__(self, topic):
        self.points = []
        self.bots = []
        self.topic = topic

        self.sub = rospy.Subscriber(topic, Point, self.callback)

    def callback(self, data):
        self.points.append((data.x, data.y))

    def plot(self):
        self.points = np.array(self.points)
        plt.scatter(self.points[:,0], self.points[:, 1])

def get_topics():
        topics = client.get_published_topics()
        topics = [x[0] for x in topics]
        print("TOPICS - ", topics)
        return [x for x in topics if 'sim_state' in x]

if __name__ == '__main__':
	rospy.init_node('simulation_plot_listener', anonymous=True)
	topics  = get_topics()
	plotters = []
	for t in topics:
		plotters.append(SimPathPlotter(t))
	
	while not rospy.is_shutdown():
		pass
	
	trajectories = []
	for plotter in plotters:
		print(plotter.topic)
		trajectories.append(np.array(plotter.points))

	for t in trajectories:
		print(len(t))
		plt.scatter(t[:, 0], t[:, 1])
	plt.show()

