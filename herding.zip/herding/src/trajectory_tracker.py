#!/usr/bin/env python
"""
Author: Amay Saxena 
"""
from calibration import calibrate, quaternion_matrix
import rospy
from geometry_msgs.msg import Twist, Vector3, Point, Quaternion
from turtlesim.msg import Pose
from nav_msgs.msg import Odometry
import numpy as np
import tf2_ros
import tf
from constants import turtlebot_colors
from calibration import all_active_bots
import math
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import axes3d, Axes3D
from scipy import optimize
import time

class TrajectoryTracker:
	def __init__(self, trajectory, sheep_topic):
		self.pub = rospy.Publisher('current_target', Quaternion, queue_size=1)
		self.sub = rospy.Subscriber(sheep_topic, Point, self.subscribe)
		loc = rospy.wait_for_message(sheep_topic, Point)
		self.current_sheep_loc = np.array([loc.x, loc.y])
		self.trajectory = trajectory
		self.dist_thresh = 1.0

	def subscribe(self, point):
		self.current_sheep_loc = np.array([point.x, point.y])

	def track(self):
		i = 0
		while i < len(self.trajectory):
			t = self.trajectory[i][:2]
			s = self.current_sheep_loc
			dist = np.linalg.norm(s - t) 
			print dist
			if  dist < self.dist_thresh:
				i += 1
			else:
				self.pub.publish(Quaternion(t[0], t[1], self.trajectory[i][2], self.trajectory[i][3]))

if __name__=='__main__':
	rospy.init_node('tracker')
	traj = np.array([
		[1050, 700, 0.4, 0.0],
		])
	# ways = np.load('plan.npy')
	# dists = np.load('running_dists.npy')
	# traj = np.zeros((len(ways), 4))
	# traj[:, :3] = ways
	# traj[:, 3] = dists
	t = TrajectoryTracker(traj, '/sim_state_pink')
	rospy.sleep(5)
	print "Starting to Track"
	t.track()
