# from scipy.spatial import Voronoi
# import time
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle, Wedge, Polygon
# from matplotlib import collections  as mc
# import numpy as np
# from shapely.geometry import Point
# from shapely.geometry.polygon import Polygon
# from collections import defaultdict
# import heapq

# class PriorityQueue:
#     def __init__(self):
#         self.elements = []
    
#     def empty(self):
#         return len(self.elements) == 0
    
#     def put(self, item, priority):
#         heapq.heappush(self.elements, (priority, item))
    
#     def get(self):
#         return heapq.heappop(self.elements)[1]

# class VoronoiPlanner:
#     def __init__(self, obstacles, boundary):
#         '''
#         obstacles = [[(x1, y1), (x2, y2)...], ...]
#         Each obstacle is a polygon, specified by a sequence of vertices
#         '''
#         self.obstacles = obstacles
#         self.boundary = boundary
#         self.points_per_edge = 100

#         self.points = []
#         for o in obstacles + [boundary]:
#             for i in range(len(o)):
#                 p1 = o[i]
#                 p2 = o[(i+1)%len(o)]
#                 x_samples = np.linspace(p1[0], p2[0], 
#                             num=self.points_per_edge, endpoint=True)
#                 y_samples = np.linspace(p1[1], p2[1], 
#                             num=self.points_per_edge, endpoint=True)
#                 for x, y in zip(x_samples, y_samples):
#                     self.points.append((x, y))
#         self.points = np.array(self.points)
#         self.vor = Voronoi(self.points)
#         self.vertices = self.vor.vertices 
#         ridges = np.array(self.vor.ridge_vertices)
#         self.ridges = ridges[(ridges[:, 0] != -1) & (ridges[:, 1] != -1)]
#         self.filter_points()
#         print len(self.ridges)
#         self.build_graph()

#     def filter_points(self):
#         for i, v in enumerate(self.vertices):
#             for o in self.obstacles:
#                 point = Point(*v)
#                 if Polygon(o).contains(point):
#                     self.remove_point(i)

#     def build_graph(self):
#         self.neighbours = defaultdict(list)
#         for i, j in self.ridges:
#             self.neighbours[i].append(j)
#             self.neighbours[j].append(i)

#     def find_nearest_vertex(self, p):
#         points = [i for i in self.neighbours]
#         keyfunc = lambda i: np.linalg.norm(p - self.vertices[i])
#         return min(points, key=keyfunc)

#     def a_star_search(self, heuristic, start, goal):
#         frontier = PriorityQueue()
#         frontier.put(start, 0)
#         came_from = {}
#         cost_so_far = {}
#         came_from[start] = None
#         cost_so_far[start] = 0

#         cost = lambda i, j: np.linalg.norm(self.vertices[i] - self.vertices[j])
        
#         while not frontier.empty():
#             current = frontier.get()
            
#             if current == goal:
#                 break
            
#             for next in self.neighbours[current]:
#                 new_cost = cost_so_far[current] + cost(current, next)
#                 if next not in cost_so_far or new_cost < cost_so_far[next]:
#                     cost_so_far[next] = new_cost
#                     priority = new_cost + heuristic(next)
#                     frontier.put(next, priority)
#                     came_from[next] = current
#         return came_from, cost_so_far

#     def reconstruct_path(self, came_from, start, goal):
#         current = goal
#         path = []
#         while current != start:
#             path.append(current)
#             current = came_from[current]
#         path.append(start)
#         path.reverse()
#         return path

#     def find_plan(self, start, end):
#         start_real, end_real = np.array(start), np.array(end)
#         heuristic = lambda p: np.linalg.norm(end - p)
#         start = self.find_nearest_vertex(start_real)
#         end = self.find_nearest_vertex(end_real)
#         came_from, cost_so_far = self.a_star_search(heuristic, start, end)
#         return self.reconstruct_path(came_from, start, end)

#     def remove_point(self, index):
#         self.ridges = self.ridges[(self.ridges[:, 0] != index) & (self.ridges[:, 1] != index)]

#     def plot(self, path=None):
#         lines = []
#         for r in self.ridges:
#             i, j = r
#             lines.append((self.vor.vertices[i], self.vor.vertices[j]))
#         lc = mc.LineCollection(lines, colors=(1, 0, 0, 1), linewidths=2)

#         fig, ax = plt.subplots()
#         ax.add_collection(lc)
#         plt.scatter(self.points[:,0], self.points[:, 1])

#         if path != None:
#             lines = []
#             for k in range(len(path)-1):
#                 i, j = path[k], path[k+1]
#                 lines.append((self.vor.vertices[i], self.vor.vertices[j]))
#             lc2 = mc.LineCollection(lines, colors=(0, 1, 0, 1), linewidths=2)
#             ax.add_collection(lc2)
#         plt.show()


# if __name__ == '__main__':

#     print("START", time.time())

#     obstacles = [[(100, 230), (120, 230), (120, 480), (100, 480)],
#                     [(120, 20), (240, 20), (240, 70), (120, 70)],
#                     [(330, 100), (390, 100), (390, 150), (330, 150)],
#                     [(280, 280), (310, 280), (310, 310), (280, 310)]
#                     ]
#     boundary = [(0, 0), (500, 0), (500, 500), (0, 500)]

#     v = VoronoiPlanner(obstacles, boundary)
#     path = v.find_plan((0, 0), (440, 280))
#     print(path)

#     print("END", time.time())

#     v.plot(path)

#     # obstacles = [[(100, 230), (120, 230), (120, 480), (100, 480)],
#     #                 [(120, 20), (240, 20), (240, 70), (120, 70)],
#     #                 [(330, 100), (390, 100), (390, 150), (330, 150)],
#     #                 [(280, 280), (310, 280), (310, 310), (280, 310)]
#     #                 ]


from scipy.spatial import Voronoi
import time
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Wedge, Polygon
from matplotlib import collections  as mc
import numpy as np
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
from collections import defaultdict
import heapq

class PriorityQueue:
    def __init__(self):
        self.elements = []
    
    def empty(self):
        return len(self.elements) == 0
    
    def put(self, item, priority):
        heapq.heappush(self.elements, (priority, item))
    
    def get(self):
        return heapq.heappop(self.elements)[1]

class VoronoiPlanner:
    def __init__(self, obstacles, boundary):
        '''
        obstacles = [[(x1, y1), (x2, y2)...], ...]
        Each obstacle is a polygon, specified by a sequence of vertices
        '''
        self.min_gap = 20
        self.obstacles = obstacles
        self.boundary = boundary
        self.points_per_edge = 100
        self.step = 10.0
        self.max_dist = 0.8 * 200

        self.points = []
        for o in obstacles + [boundary]:
            for i in range(len(o)):
                p1 = o[i]
                p2 = o[(i+1)%len(o)]
                
                x_num = int(abs(p2[0] - p1[0]) / self.step)
                x_samples = np.linspace(p1[0], p2[0], 
                            num=self.points_per_edge, endpoint=True)
                y_num = int(abs(p2[1] - p1[1]) / self.step)
                y_samples = np.linspace(p1[1], p2[1], 
                            num=self.points_per_edge, endpoint=True)

                for x, y in zip(x_samples, y_samples):
                    self.points.append((x, y))

        self.points = np.array(self.points)
        self.vor = Voronoi(self.points)
        self.vertices = self.vor.vertices 
        ridges = np.array(self.vor.ridge_vertices)
        self.vor.ridge_vertices = ridges
        narrow_mask = self.narrow_paths_mask()
        # print narrow_mask.shape
        boundary_mask = (self.vor.ridge_vertices[:, 0] != -1) & (self.vor.ridge_vertices[:, 1] != -1)
        # print boundary_mask.shape
        obstacle_mask = self.filter_points()
        # print obstacle_mask.shape
        # print(self.ridges.shape)
        self.mask = narrow_mask & boundary_mask & obstacle_mask
        self.ridges = self.vor.ridge_vertices[self.mask]
        self.dists = self.dists[self.mask]
        print(len(self.dists))
        print(len(self.ridges))
        self.build_graph()

    def filter_points(self):
        mask = np.zeros(len(self.vor.ridge_vertices), dtype=bool)
        for i, v in enumerate(self.vertices):
            for o in self.obstacles:
                point = Point(*v)
                if Polygon(o).contains(point):
                    mask |= self.remove_point(i)
        return mask

    def narrow_paths_mask(self):
        one_end = self.vor.ridge_points[:, 0]
        other_end = self.vor.ridge_points[:, 1]
        p1 = self.vor.points[one_end]
        p2 = self.vor.points[other_end]
        self.dists = np.linalg.norm((p1 - p2)/2, axis=1)
        return self.dists > self.min_gap

    def build_graph(self):
        self.neighbours = defaultdict(list)
        self.radii = defaultdict(float)
        for idx, (i, j) in enumerate(self.ridges):
            self.neighbours[i].append(j)
            self.neighbours[j].append(i)
            self.radii[(i, j)] = self.dists[idx]
            self.radii[(j, i)] = self.dists[idx]

    def find_nearest_vertex(self, p):
        points = [i for i in self.neighbours]
        keyfunc = lambda i: np.linalg.norm(p - self.vertices[i])
        return min(points, key=keyfunc)

    def a_star_search(self, heuristic, start, goal):
        frontier = PriorityQueue()
        frontier.put(start, 0)
        came_from = {}
        cost_so_far = {}
        came_from[start] = None
        cost_so_far[start] = 0

        cost = lambda i, j: np.linalg.norm(self.vertices[i] - self.vertices[j])
        
        while not frontier.empty():
            current = frontier.get()
            
            if current == goal:
                break
            
            for next in self.neighbours[current]:
                new_cost = cost_so_far[current] + cost(current, next)
                if next not in cost_so_far or new_cost < cost_so_far[next]:
                    cost_so_far[next] = new_cost
                    priority = new_cost + heuristic(next)
                    frontier.put(next, priority)
                    came_from[next] = current
        return came_from, cost_so_far

    def reconstruct_path(self, came_from, start, goal):
        current = goal
        path = []
        while current != start:
            path.append(current)
            current = came_from[current]
        path.append(start)
        path.reverse()
        return path

    def generate_dists(self, path):
        dist_to_go = [0]
        dist = 0
        for i in range(len(path)-1, 0, -1):
            p, q = path[i], path[i - 1]
            dist += np.linalg.norm(p - q)
            dist_to_go.append(dist)
        return dist_to_go[::-1]

    def find_plan(self, start, end):
        start_real, end_real = np.array(start), np.array(end)
        heuristic = lambda p: np.linalg.norm(end - p)
        start = self.find_nearest_vertex(start_real)
        end = self.find_nearest_vertex(end_real)
        came_from, cost_so_far = self.a_star_search(heuristic, start, end)
        path = self.reconstruct_path(came_from, start, end)
        rads = []
        for i in range(len(path) - 1):
            idx, jdx = path[i], path[i+1]
            dist = self.radii[(idx, jdx)]
            if dist > self.max_dist + 0.1*200:
                rads.append(self.max_dist)
            else:
                rads.append(0.6 * dist)
        rads = [self.max_dist] + rads
        return path, rads

    def remove_point(self, index):
        return (self.vor.ridge_vertices[:, 0] != index) & (self.vor.ridge_vertices[:, 1] != index)

    def plot(self, path=None):
        lines = []
        for r in self.ridges:
            i, j = r
            lines.append((self.vor.vertices[i], self.vor.vertices[j]))
        lc = mc.LineCollection(lines, colors=(1, 0, 0, 1), linewidths=2)

        fig, ax = plt.subplots()
        ax.add_collection(lc)
        plt.scatter(self.points[:,0], self.points[:, 1])

        if path != None:
            lines = []
            for k in range(len(path)-1):
                i, j = path[k], path[k+1]
                lines.append((self.vor.vertices[i], self.vor.vertices[j]))
            lc2 = mc.LineCollection(lines, colors=(0, 1, 0, 1), linewidths=2)
            ax.add_collection(lc2)
        plt.show()

    def process_plan(self, path, rads):
        plan = []
        for t, r in zip(path, rads):
            x, y = self.vor.vertices[t]
            plan.append([x, y, r])
        return np.array(plan)


if __name__ == '__main__':

    t0 = time.time()

    # obstacles = [[(100, 230), (120, 230), (120, 480), (100, 480)],
    #                 [(120, 20), (240, 20), (240, 70), (120, 70)],
    #                 [(330, 100), (390, 100), (390, 150), (330, 150)],
    #                 [(280, 280), (310, 280), (310, 310), (280, 310)]
    #                 ]

    # obstacles = [[(0, 400), (390, 400), (390, 700), (0, 700)],
    #             [(1000, 400), (610, 400), (610, 700), (1000, 700)]]

    # boundary = [(0, 0), (1000, 0), (1000, 1000), (0, 1000)]
    # start = (500, 200)
    # end = (702, 850)

    obstacles = [[(500, 0), (500, 700), (700, 700), (700, 0)],
                [(1300, 1000), (1500, 1000), (1500, 300), (1300, 300)]]

    boundary = [(0, 0), (2000, 0), (2000, 1000), (0, 1000)]
    start = (250, 300)
    end = (1750, 700)



    v = VoronoiPlanner(obstacles, boundary)
    path, rads = v.find_plan(start, end)
    plan = v.process_plan(path, rads)
    plan[:, 2] /= 200.0
    # print plan
    dists_to_go = np.array(v.generate_dists(plan[:, :2])) / 200.0
    # print dists_to_go
    np.save('plan', plan)
    np.save('running_dists', dists_to_go)
    # print(path)

    print "Planning Took", time.time() - t0, "seconds."

    v.plot(path)

    # obstacles = [[(100, 230), (120, 230), (120, 480), (100, 480)],
    #                 [(120, 20), (240, 20), (240, 70), (120, 70)],
    #                 [(330, 100), (390, 100), (390, 150), (330, 150)],
    #                 [(280, 280), (310, 280), (310, 310), (280, 310)]
    #                 ]
