#!/usr/bin/env python
"""
Author: Amay Saxena 
"""
from calibration import calibrate, quaternion_matrix
import rospy
from geometry_msgs.msg import Twist, Vector3, Point, Quaternion
from turtlesim.msg import Pose
from nav_msgs.msg import Odometry
import numpy as np
import tf2_ros
import tf
from constants import turtlebot_colors
from calibration import all_active_bots
import math
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import axes3d, Axes3D
from scipy import optimize
import time

def quaternion_to_euler(x, y, z, w):
        t0 = +2.0 * (w * x + y * z)
        t1 = +1.0 - 2.0 * (x * x + y * y)
        X = math.degrees(math.atan2(t0, t1))

        t2 = +2.0 * (w * y - z * x)
        t2 = +1.0 if t2 > +1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        Y = math.degrees(math.asin(t2))

        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        Z = math.degrees(math.atan2(t3, t4))

        return X*(np.pi/180), Y*(np.pi/180), Z*(np.pi/180)

def rot_matrix(phi):
	return np.array([[np.cos(phi), -np.sin(phi)], [np.sin(phi), np.cos(phi)]])

class Robot:
	def __init__(self, turtlebot, sim=False):
		self.turtlebot = "/" + turtlebot
		self.simulation = sim

		if not self.simulation:
			self.sub = rospy.Subscriber(self.turtlebot + '/odom', Odometry, self.subscribe)
			self.pub = rospy.Publisher(self.turtlebot + '/mobile_base/commands/velocity', Twist, queue_size=1)
		else:
			self.sub = rospy.Subscriber('/sim_state_' + self.turtlebot[1:], Point, self.subscribe)
			self.pub = rospy.Publisher('/vel_cmd_' + self.turtlebot[1:], Point, queue_size=1)

		self.l = 0.25
		self.g = None
		self.xy = np.array([0.0, 0.0])
		self.phi = 0.0
		self.p = self.xy + np.array([self.l, 0.0])
		self.R = np.eye(2)
		self.orientation = None
		self.min_vel = 0 if self.simulation else 0.005#0.01

	def subscribe(self, msg):
		if self.simulation:
			self.p = np.array([msg.x / 200.0, msg.y / 200.0])
		else:
			trans = np.array([eval('msg.pose.pose.position.' + p) for p in ('x', 'y', 'z')])
			quat = [eval('msg.pose.pose.orientation.' + p) for p in ('x', 'y', 'z', 'w')]
			self.phi = quaternion_to_euler(*quat)[2]
			self.xy = trans[:2]
			self.R = rot_matrix(self.phi)
			self.p = self.xy + self.R[:, 0] * self.l

	def hol_to_uni(self, p_dot):
		bx = self.R[:, 0]
		by = self.R[:, 1]
		v = np.dot(bx, p_dot)
		w = (1.0/self.l) * np.dot(by, p_dot)
		return v, w

	def cmd(self, p_dot):
		if not self.simulation:
			if np.linalg.norm(p_dot) > self.min_vel:
				v, w = self.hol_to_uni(p_dot)
			else:
				v, w = 0, 0
			t = Twist(Vector3(v, 0, 0), Vector3(0, 0, w))
		else:
			if np.linalg.norm(p_dot) < self.min_vel:
				t = Point(0, 0, 0)
			else:
				t = Point(p_dot[0], p_dot[1], 0)
		self.pub.publish(t)

	def __str__(self):
		return self.turtlebot

	def __repr__(self):
		return self.turtlebot


class World:
	def __init__(self, herd):
		self.herd = herd
		self.sheep = herd.sheep
		self.dogs = herd.dogs
		self.K = 0.005 if sheep[0].simulation else 0.1
		self.rate = rospy.Rate(20)
		self.target_sub = rospy.Subscriber('current_target', Quaternion, self.target_subscribe)
		targ = rospy.wait_for_message('current_target', Quaternion)
		self.target = np.array([targ.x, targ.y])
		self.radius = targ.z
		self.dist = targ.w
		self.distances = []
		self.times = []

	def target_subscribe(self, t):
		self.target = np.array([t.x, t.y])
		self.radius = t.z
		self.dist = t.w

	def potential(self, pos, dogs):
		vel = 0.0
		for dog in dogs:
			xy = dog
			vel += (1.0 / np.linalg.norm(pos - xy) ** 2)
		return self.K * vel

	def velocity(self, pos):
		vel = np.zeros(2)
		for dog in dogs:
			xy = dog.p
			vel += ((pos - xy) / np.linalg.norm(pos - xy) ** 3)

		print self.K * vel
		return self.K * vel

	def get_target(self):
		# return np.array([800.0/200.0, 350.0/200.0])
		return self.target / 200.0
		# if time.time() - t0 < 30:
		# return np.array([5.0, 0.0])
		# else:
		# 	return np.array([5.0, 5.0])
		# return np.array([500.0/200.0, 900.0/200.0])

	def execute(self):
		print "Started Execution"
		t0 = time.time()
		while not rospy.is_shutdown():#time.time() - t0 < 120:#not rospy.is_shutdown():
			for s in self.sheep:
				vel = self.velocity(s.p)
				s.cmd(vel)
			d = self.dist + np.linalg.norm(self.herd.s() - self.get_target())
			self.distances.append(d)
			self.times.append(time.time() - t0)
			print d
			# if time.time() - t0 > 6:
			# 	self.herd.r = 0.5
			# 	print "Decreasing Radius"
			# if time.time() - t0 > 12:
			# 	self.herd.r = 0.9
			# 	print "Increasing Radius"

			self.herd.r = self.radius
			self.herd.cmd_to_target(self.get_target(), dist=d)
			self.rate.sleep()

		np.save('plot_prop3', np.array([self.times, self.distances]))
		plt.plot(self.times, self.distances)
		plt.show()

		print("Cleaning Up")
		for s in self.sheep:
			s.cmd(np.array([0, 0]))
		for d in self.dogs:
			d.cmd(np.array([0, 0]))

def plot_function(f, rng=(0, 2*np.pi)):
	xs = np.linspace(rng[0], rng[1], num=1000)[1:]
	ys = []
	for x in xs:
		ys.append(f(x)) 
	ys = np.array(ys)
	plt.plot(xs[~np.isnan(ys)], ys[~np.isnan(ys)])
	plt.show()

class Herd:
	def __init__(self, sheep, dogs):
		self.dogs = dogs
		self.sheep = sheep

		self.l = 0.5
		self.phi = 0.0
		self.min_vel = 0.01
		self.r = 0.4
		self.m = len(dogs)
		self.R = np.eye(2)
		self.dog_KP = 0.6
		self.herd_KP = 5.0

		self.proportional = True

		self.herd_K_theta = 2.0#2.0 if sheep[0].simulation else 2.0
		self.herd_K_v = 20.0 if sheep[0].simulation else 0.7

	def s(self):
		return np.mean([s.p for s in self.sheep], axis=0)
		
	def hol_to_uni(self, p_dot):
		bx = self.R[:, 0]
		by = self.R[:, 1]
		v = np.dot(bx, p_dot)
		w = (1.0/self.l) * np.dot(by, p_dot)
		return v, w

	def solve_for_delta(self, v):
		v = 7 if v > 7 else v
		v = 0 if v < 0 else v
		m = self.m
		denom = 2 - 2*m
		u = lambda x: np.sin((m*x)/denom)
		w = lambda x: self.r**2 * np.sin(x/denom)
		f = lambda x: (u(x)/w(x))-v
		sol = optimize.root_scalar(f, bracket=[0.01, 2*np.pi-0.01], 
			method='brentq')
		return sol.root

	def cmd(self, p_dot):
		phi = np.arctan2(p_dot[1], p_dot[0])
		self.R = rot_matrix(phi)

		v, w = self.hol_to_uni(p_dot)
		delta = self.solve_for_delta(v)
		delta_i = lambda i: delta * (float(2*i - self.m - 1)/float(2*self.m - 2))
		alphas = [phi + np.pi + delta_i(i+1) for i in range(self.m)]

		s = self.s()
		
		dog_pos_desired = np.array([s + self.r * np.array([np.cos(alphas[j]), 
			np.sin(alphas[j])]) for j in range(self.m)])
		dog_pos_current = [d.p for d in self.dogs]
		dog_vels = self.dog_KP * (dog_pos_desired - dog_pos_current)
		
		for dog, vel in zip(self.dogs, dog_vels):
			dog.cmd(vel)

	def cmd_to_target(self, target, dist=None):
		direction = (target - self.s())
		if dist==None:
			dist = np.linalg.norm(direction)
			direction = direction / dist
		else:
			direction = direction / np.linalg.norm(direction)
		mag = np.arctan(self.herd_K_theta * dist)
		if self.proportional:
			p_dot = self.herd_KP * (target - self.s())
		else:
			p_dot = self.herd_K_v * mag * direction
		self.cmd(p_dot)

if __name__ == '__main__':
	rospy.init_node('converter', anonymous=True)

	simulation = True
	if simulation:
		sheep = ['pink']#, 'pinky', 'pinku']
		dogs = ['green', 'black', 'blue']#, 'kutta']
	else:
		sheep = ['pink']
		dogs = ['green', 'black', 'blue']

	# dogs = dogs[::-1]

	dogs = [Robot(d, sim=simulation) for d in dogs]
	sheep = [Robot(s, sim=simulation) for s in sheep]
	print "Made Robots"
	rospy.sleep(5)
	h = Herd(sheep, dogs)
	w = World(h)
	print "Made World"
	# t0 = time.time()
	w.execute()
