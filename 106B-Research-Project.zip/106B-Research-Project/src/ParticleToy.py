__author__ = 'Aakarsh Gupta'

from graphics import *
import time
from Button import Button
from Particle import *
import numpy as np
import matplotlib.pyplot as plt
import rospy
from std_msgs.msg import String

dog_col = (83, 51, 237)
sheep_col = (255, 203, 5)

green = tuple(dog_col)
black = tuple(dog_col)
blue = tuple(dog_col)
kutta = tuple(dog_col)
pink = tuple(sheep_col)
pinky = tuple(sheep_col)
pinku = tuple(sheep_col)

class ParticleToy:

    def __init__(self):
        print("LAUNCHING WINDOW")
        self.win = GraphWin("Particles", 2000, 1000, False)
        x1, y1, x2, y2 = 0, 0, 2000, 1000
        self.map_arr = np.zeros((x2-x1, y2-y1))
        self.win.setCoords(x1, y1, x2, y2)
        self._mouseLocation = Point(0, 0)
        self._obstacles = []
        # self.map_sub = rospy.Subscriber('exploration_map', String, self.subscriber)
        self.map_pub = rospy.Publisher('map_state', String, queue_size=10)
        self.particleSize = 15
        self.numOfParticles = 4
        self._particles = []
        self.cols = ['green', 'black', 'blue', 'pink']
         # 'kutta', 'pink', 'pinky', 'pinku']
        self.colors = [green, black, blue, pink]
        # kutta, pink, pinky, pinku]
        self.showWelcomePage()
        self._gameElements = []
        self._welcomePageElements = []


    def startGame(self):
        print("STARTING GAME")
        self.win.setBackground("black")
        self.speed = 0.001
        self._initializeGameView()
        self._timer()
        self.win.checkMouse()

    def _initializeGameView(self):
        print("INITIALIZING GAME VIEW")
        self.lastFpsUpdate = 0
        self.frameCounter = 0
        self._gameElements = []
        self._initializeButtons()
        self._initializeObstacles() # Create map
        self._initializeParticles()

        keyFunctionsPrompt = Text(Point(430, 35), "Press 'q' to Quit.     Press 'r' to Reset. ").draw(self.win)
        self.fpsText = Text(Point(50, 900), "")
        self._gameElements.append(keyFunctionsPrompt)
        self._gameElements.append(self.fpsText)

    def _initializeButtons(self):
        print("INITIALIZING BUTTONS")
        self.backToMenuButton = Button("Back to Menu", Point(20, 950), Point(170, 980), self.win)
        self._gameElements.append(self.backToMenuButton)

    def _timer(self):
        print("STARTING GAME TIMER")
        while self._running:
            self.frameCounter += 1

            if time.time() - self.lastFpsUpdate > 1:
                self.fpsText.setText(self.frameCounter)
                self.fpsText.undraw()
                self.fpsText.draw(self.win)
                self.lastFpsUpdate = time.time()
                self.frameCounter = 0

            self._keyboardCallback()
            self._mouseCallback()
            self._displayCallback()


    def _keyboardCallback(self):
        key = self.win.checkKey()
        if key == "q":
            print("QUITTING")
            self._running = False
        if key == "r":
            print("RESETTING PARTICLES")
            self._killParticles()
            self._initializeParticles()
        return

    def _mouseCallback(self):
        mouseLocation = Point(0, 0)
        if mouseLocation.getX() == 0 and mouseLocation.getY() == 0:
            point = self.win.checkMouse()
        else:
            point = None
        if point:
            mouseLocation = point

        if self.backToMenuButton.clicked(mouseLocation):
            self.backToMenu()
        return

    def _displayCallback(self):
        self.map_pub.publish(str(self._obstacles))
        self._calculateParticleMovement()
        self.win.flush()
        return

    def _initializeObstacles(self):
        pass
        # , polygons
        # polygons is a list of lists of vertices that define all of the obstacles in the map

        # for polygon in polygons:
        #     obstacle = Polygon(polygon)
        #     obstacle.draw(self.win)

        # vertices = [Point(100, 900),
        #             Point(100, 700),
        #             Point(700, 700),
        #             Point(700, 300),
        #             Point(300, 300),
        #             Point(300, 100),
        #             Point(900, 100),
        #             Point(900, 900)]

        # vertices1 = [Point(0, 400),
        #             Point(390, 400),
        #             Point(390, 700),
        #             Point(0, 700)]

        # vertices2 = [Point(1000, 400),
        #             Point(610, 400),
        #             Point(610, 700),
        #             Point(1000, 700)]

        vertices1 = [Point(500, 0),
                    Point(500, 700),
                    Point(700, 700),
                    Point(700, 0)]

        vertices2 = [Point(1300, 1000),
                    Point(1500, 1000),
                    Point(1500, 300),
                    Point(1300, 300)]

        center = (1050, 700)
        offset = 20

        target = [Point(center[0]-offset, center[1]+offset),
                  Point(center[0]+offset, center[1]+offset),
                  Point(center[0]-offset, center[1]-offset),
                  Point(center[0]+offset, center[1]-offset)]

        # obs_color = '#f62459'
        # obstacle1 = Polygon(self.map_arr, vertices1)
        # obstacle1.setFill(obs_color)
        # obstacle1.draw(self.win)
        # self.map_arr = obstacle1.map_arr

        # obstacle2 = Polygon(self.map_arr, vertices2)
        # obstacle2.draw(self.win)
        # obstacle2.setFill(obs_color)
        # self.map_arr = obstacle2.map_arr

        obstacle3 = Polygon(self.map_arr, target)
        obstacle3.draw(self.win)
        obstacle3.setFill('#7befb2')
        self.map_arr = obstacle3.map_arr


    def _initializeParticles(self):
        print("INITIALIZING PARTICLES")
        r = Random()
        min_x, min_y = float('inf'), float('inf')
        max_x, max_y = 0, 0

        # dog_pos = [(100, 100), (900, 100), (500, 793)]
        # dog_pos = [(300, 100), (500, 100), (700, 100)]
        # sheep_pos = (500, 200)

        sheep_pos = (325, 470)
        dog_pos = [(sheep_pos[0]-100, sheep_pos[1]-150), (sheep_pos[0], sheep_pos[1]-150), (sheep_pos[0]+100, sheep_pos[1]-150), sheep_pos]
        # , (240, 200), (260, 200), (250, 220)]
        # sheep_pos = [(245, 200), (255, 200)]

        for i in range(self.numOfParticles):
            if i < self.numOfParticles-1:
                # rand_x = r.randrange(100, 900)
                # max_x = max(max_x, rand_x)
                # min_x = min(min_x, rand_x)
                # rand_y = r.randrange(100, 900)
                # max_y = max(max_y, rand_y)
                # min_y = min(min_y, rand_y)
                # particle = Particle(self.win, Point(rand_x, rand_y))
                particle = Particle(self.win, self.cols[i], Point(dog_pos[i][0], dog_pos[i][1]))
            else:
                # particle = Particle(self.win, Point(r.randrange(min_x+50, max_x-50), r.randrange(min_y+50, max_y-50)), True) # Initialize sheep within area enclosed by dogs
                # particle = Particle(self.win, self.cols[i], Point(r.randrange(100+50, 900-50), r.randrange(100+50, 793-50)), True) # Initialize sheep within area enclosed by dogs
                # particle = Particle(self.win, self.cols[i], Point(sheep_pos[i][0], sheep_pos[i][1]), True) # Initialize sheep within area enclosed by dogs
                particle = Particle(self.win, self.cols[i], Point(dog_pos[i][0], dog_pos[i][1]), True) # Initialize sheep within area enclosed by dogs


            self._particles.append(particle)
            
            particle.setColor('#%02X%02X%02X' % self.colors[i])

            particle.setSize(self.particleSize)
            particle.draw()


    def findParticle(self, particle):
        if particle.position.getX() < 0:
            return "left"
        if particle.position.getX() > 1000:
            return "right"
        if particle.position.getY() < 100:
            return "below"
        if particle.position.getY() > 1000:
            return "above"
        else:
            return "in"

    def reflect(self, particle):
        if self.findParticle(particle) == "in":
            return False
        elif self.findParticle(particle) == "left":
            particle.setParticleMovement(abs(particle.dX), particle.dY)
            return True
        elif self.findParticle(particle) == "right":
            particle.setParticleMovement(-abs(particle.dX), particle.dY)
            return True
        elif self.findParticle(particle) == "bottom":
            particle.setParticleMovement(particle.dX, abs(particle.dY))
            return True
        elif self.findParticle(particle) == "top":
            particle.setParticleMovement(particle.dX, -abs(particle.dY))
            return True


    def _calculateParticleMovement(self):

        for particle in self._particles:
            particle.move()


    def _killParticles(self):
        print("KILLING PARTICLES")
        for particle in self._particles:
            particle.undraw()
        self._particles = []


    def showWelcomePage(self):
        print("SHOWING WELCOME PAGE")
        self._welcomePageElements = []
        self.win.setBackground("Dark Gray")
        atWelcome = True

        welcomeText = Text(Point(500, 850), "Herd Movement Generator")
        welcomeText.setSize(28)
        welcomeText.setTextColor("BLUE")
        welcomeText.draw(self.win)
        self._welcomePageElements.append(welcomeText)

        startButton = Button("Start", Point(400, 350), Point(600, 450), self.win)
        startButton.setTextSize(32)
        self._welcomePageElements.append(startButton)

        numOfParticlesText = Text(Point(270, 700), "Number of Particles").draw(self.win)
        self._welcomePageElements.append(numOfParticlesText)

        numOfParticlesInput = Entry(Point(400, 700), 8).setText("4").draw(self.win)
        self._welcomePageElements.append(numOfParticlesInput)

        numOfParticlesInfoText = Text(Point(650, 700), "(2-10)").draw(self.win)
        self._welcomePageElements.append(numOfParticlesInfoText)

        # numOfDogsText = Text(Point(270, 700), "Number of Dogs").draw(self.win)
        # self._welcomePageElements.append(numOfDogsText)
        #
        # numOfDogsInput = Entry(Point(400, 700), 8).setText("4").draw(self.win)
        # self._welcomePageElements.append(numOfDogsInput)
        #
        # numOfDogsInfoText = Text(Point(650, 700), "(2-10)").draw(self.win)
        # self._welcomePageElements.append(numOfDogsInfoText)
        #
        # numOfSheepText = Text(Point(270, 700), "Number of Dogs").draw(self.win)
        # self._welcomePageElements.append(numOfSheepText)
        #
        # numOfSheepInput = Entry(Point(400, 700), 8).setText("4").draw(self.win)
        # self._welcomePageElements.append(numOfSheepInput)
        #
        # numOfSheepInfoText = Text(Point(650, 700), "(2-10)").draw(self.win)
        # self._welcomePageElements.append(numOfSheepInfoText)

        valid = True
        valid2 = True

        while atWelcome:
            time.sleep(.1)
            point = self.win.checkMouse()
            if point and valid and valid2 and startButton.clicked(point):
                self._running = True
                self.hideWelcomePage()
                self.startGame()
                atWelcome = False
                return
            elif self.win.checkKey() == "q":
                print("QUITTING")
                atWelcome = False
                return

            if numOfParticlesInput.getText() != "":
                try:
                    self.numOfParticles = int(numOfParticlesInput.getText())

                    if self.numOfParticles < 2 or self.numOfParticles > 10:
                        self.textErrorMessage(numOfParticlesInfoText, "Invalid Entry. Enter 2-10", Point(750, 700))
                        valid2 = False
                    else:
                        self.textErrorMessage(numOfParticlesInfoText, "(2-10)", Point(650, 700), "BLACK")
                        valid2 = True
                except:
                    self.textErrorMessage(numOfParticlesInfoText, "Invalid Entry. Numbers Only", Point(750, 700))
                    valid2 = False

            # if numOfDogsInput.getText() != "":
            #     try:
            #         self.numOfDogs = int(numOfDogsInput.getText())
            #
            #         if self.numOfDogs < 1:
            #             self.textErrorMessage(numOfDogsInfoText, "Invalid Entry. Enter >0", Point(750, 700))
            #             valid2 = False
            #         else:
            #             self.textErrorMessage(numOfDogsInfoText, "(>0)", Point(650, 700), "BLACK")
            #             valid2 = True
            #     except:
            #         self.textErrorMessage(numOfDogsInfoText, "Invalid Entry. Numbers Only", Point(750, 700))
            #         valid2 = False
            #
            # if numOfSheepInput.getText() != "":
            #     try:
            #         self.numOfSheep = int(numOfSheepInput.getText())
            #
            #         if self.numOfDogs < 1:
            #             self.textErrorMessage(numOfSheepInfoText, "Invalid Entry. Enter 0 or more", Point(750, 700))
            #             valid2 = False
            #         else:
            #             self.textErrorMessage(numOfSheepInfoText, "(>0)", Point(650, 700), "BLACK")
            #             valid2 = True
            #     except:
            #         self.textErrorMessage(numOfSheepInfoText, "Invalid Entry. Numbers Only", Point(750, 700))
            #         valid2 = False

            # self.numOfParticles = self.numOfDogs + self.numOfSheep


    def textErrorMessage(self, textObject, message, newAnchor, color="RED"):
        textObject.setText(message)
        textObject.setTextColor(color)
        textObject.anchor = newAnchor
        textObject.undraw()
        textObject.draw(self.win)


    def backToMenu(self):
        print("GOING BACK TO WELCOME MENU")
        self._killParticles()
        for element in self._gameElements:
            element.undraw()
            del element

        self._running = False
        self.showWelcomePage()


    def hideWelcomePage(self):
        print("HIDING WELCOME PAGE")
        for element in self._welcomePageElements:
            element.undraw()
            del element
