#!/usr/bin/env python

import rospy
import ParticleToy
from std_msgs.msg import Int32,Int32MultiArray,MultiArrayLayout,MultiArrayDimension

 
def talker():
	pub = rospy.Publisher('sim_state', String, queue_size=10)
	rate = rospy.Rate(20) # 20hz
	while not rospy.is_shutdown():
		for particle in ParticleToy._particles:
			msg.append((particle.position.getX(), particle.position.getY()))
		pub.publish(msg)
		rate.sleep()

if __name__ == '__main__':
	rospy.init_node('simulator', anonymous=True)

	try:
		talker()
	except rospy.ROSInterruptException:
		pass