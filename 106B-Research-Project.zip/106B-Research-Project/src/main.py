__author__ = 'Aakarsh Gupta'
import sys
from ParticleToy import ParticleToy
import rospy

def main():
	rospy.init_node('simulation', anonymous=True)
	game = ParticleToy()

if __name__ == '__main__':
    main()
